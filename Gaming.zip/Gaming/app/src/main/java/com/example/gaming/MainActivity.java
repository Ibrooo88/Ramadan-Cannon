package com.example.gaming;

import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private LineChart trajectoryChart;
    private EditText angleInput;
    private EditText speedInput;
    private Button launchButton;
    private TextView distanceText;
    private TextView heightText;
    private TextView areaText;
    private TextView integrationSteps;
    private ToneGenerator toneGenerator;

    private static final double GRAVITY = 9.81;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        trajectoryChart = findViewById(R.id.trajectoryChart);
        angleInput = findViewById(R.id.angleInput);
        speedInput = findViewById(R.id.speedInput);
        launchButton = findViewById(R.id.launchButton);
        distanceText = findViewById(R.id.distanceText);
        heightText = findViewById(R.id.heightText);
        areaText = findViewById(R.id.areaText);
        integrationSteps = findViewById(R.id.integrationSteps);

        // Setup sound effect
        toneGenerator = new ToneGenerator(AudioManager.STREAM_ALARM, 100);

        // Configure chart
        setupChart();

        // Set click listener for launch button
        launchButton.setOnClickListener(v -> launchProjectile());
    }

    private void setupChart() {
        trajectoryChart.getDescription().setEnabled(false);
        trajectoryChart.setTouchEnabled(true);
        trajectoryChart.setDragEnabled(true);
        trajectoryChart.setScaleEnabled(true);
        trajectoryChart.setPinchZoom(true);
    }

    private void launchProjectile() {
        try {
            double angle = Double.parseDouble(angleInput.getText().toString());
            double initialVelocity = Double.parseDouble(speedInput.getText().toString());

            if (angle < 0 || angle > 90) {
                Toast.makeText(this, "Angle must be between 0 and 90 degrees", Toast.LENGTH_SHORT).show();
                return;
            }

            if (initialVelocity <= 0) {
                Toast.makeText(this, "Initial velocity must be greater than 0", Toast.LENGTH_SHORT).show();
                return;
            }

            // Play launch sound
            toneGenerator.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 200);

            // Calculate trajectory and results
            List<Entry> entries = calculateTrajectory(angle, initialVelocity);
            double maxDistance = calculateMaxDistance(angle, initialVelocity);
            double maxHeight = calculateMaxHeight(angle, initialVelocity);
            double area = calculateArea(angle, initialVelocity);

            // Create dataset
            LineDataSet dataSet = new LineDataSet(entries, "Projectile Path");
            dataSet.setDrawCircles(false);
            dataSet.setColor(android.R.color.holo_red_dark);
            dataSet.setLineWidth(2f);

            // Update chart
            LineData lineData = new LineData(dataSet);
            trajectoryChart.setData(lineData);
            trajectoryChart.invalidate();

            // Display results
            distanceText.setText(String.format(Locale.US, "Range: %.2f meters (%.2f miles)", maxDistance, metersToMiles(maxDistance)));
            heightText.setText(String.format(Locale.US, "Maximum Height: %.2f meters", maxHeight));
            areaText.setText(String.format(Locale.US, "Area under curve: %.2f square meters", area));

            // Show integration steps
            StringBuilder steps = new StringBuilder("Integration Process:\n");
            steps.append("1. Find time of flight: t = 2v₀sin(θ)/g\n");
            steps.append("2. Divide into 100 segments\n");
            steps.append("3. Use trapezoidal rule for area\n");
            steps.append(String.format(Locale.US, "4. Result: %.2f m²", area));
            integrationSteps.setText(steps.toString());

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    private List<Entry> calculateTrajectory(double angleDegrees, double initialVelocity) {
        List<Entry> entries = new ArrayList<>();
        double angleRadians = Math.toRadians(angleDegrees);
        double v0x = initialVelocity * Math.cos(angleRadians);
        double v0y = initialVelocity * Math.sin(angleRadians);

        double timeOfFlight = (2 * v0y) / GRAVITY;
        double timeStep = timeOfFlight / 100;

        for (double t = 0; t <= timeOfFlight; t += timeStep) {
            float x = (float) (v0x * t);
            float y = (float) (v0y * t - 0.5 * GRAVITY * t * t);
            if (y >= 0) {
                entries.add(new Entry(x, y));
            }
        }

        return entries;
    }

    private double calculateMaxDistance(double angleDegrees, double initialVelocity) {
        double angleRadians = Math.toRadians(angleDegrees);
        return (initialVelocity * initialVelocity * Math.sin(2 * angleRadians)) / GRAVITY;
    }

    private double calculateMaxHeight(double angleDegrees, double initialVelocity) {
        double angleRadians = Math.toRadians(angleDegrees);
        double v0y = initialVelocity * Math.sin(angleRadians);
        return (v0y * v0y) / (2 * GRAVITY);
    }

    private double calculateArea(double angleDegrees, double initialVelocity) {
        double angleRadians = Math.toRadians(angleDegrees);
        double timeOfFlight = (2 * initialVelocity * Math.sin(angleRadians)) / GRAVITY;
        int segments = 100;
        double dt = timeOfFlight / segments;
        double area = 0;

        // Trapezoidal rule for numerical integration
        for (int i = 0; i < segments; i++) {
            double t1 = i * dt;
            double t2 = (i + 1) * dt;
            double y1 = getHeight(t1, angleRadians, initialVelocity);
            double y2 = getHeight(t2, angleRadians, initialVelocity);
            area += 0.5 * (y1 + y2) * dt;
        }

        return area;
    }

    private double getHeight(double time, double angleRadians, double initialVelocity) {
        double v0y = initialVelocity * Math.sin(angleRadians);
        return Math.max(0, v0y * time - 0.5 * GRAVITY * time * time);
    }

    private double metersToMiles(double meters) {
        return meters * 0.000621371;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (toneGenerator != null) {
            toneGenerator.release();
            toneGenerator = null;
        }
    }
}
